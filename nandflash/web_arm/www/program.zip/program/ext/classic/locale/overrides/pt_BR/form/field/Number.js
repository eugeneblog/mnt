Ext.define("Ext.locale.pt_BR.form.field.Number", {
    override: "Ext.form.field.Number",
    minText: "O valor mínimo para este campo é {0}",
    maxText: "O valor máximo para este campo é {0}",
    nanText: "{0} não é um número válido"
});