Ext.define("Ext.locale.pt_BR.view.View", {
    override: "Ext.view.View",
    emptyText: ""
});