Ext.define('Ext.locale.pt_BR.grid.filters.filter.Number', {
    override: 'Ext.grid.filters.filter.Number',
    emptyText: 'Digite o número...'
});
