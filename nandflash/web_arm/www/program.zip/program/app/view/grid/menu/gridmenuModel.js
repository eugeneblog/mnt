Ext.define('program.view.grid.menu.gridmenuModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.grid-menu-gridmenu',
    data: {
        name: 'program'
    }

});
