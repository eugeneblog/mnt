Ext.define('program.view.grid.BackupGridModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.grid-backupgrid',
    data: {
        name: 'program'
    }

});
