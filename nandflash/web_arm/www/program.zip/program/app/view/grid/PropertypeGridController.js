Ext.define('program.view.grid.PropertypeGridController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.grid-propertypegrid'
    
});
