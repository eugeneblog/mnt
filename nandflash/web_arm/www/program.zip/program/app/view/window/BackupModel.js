Ext.define('program.view.window.BackupModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.window-backup',
    data: {
        name: 'program'
    }

});
