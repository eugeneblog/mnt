Ext.define('program.view.window.EditFileModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.window-editfile',
    data: {
        name: 'program'
    }

});
