Ext.define('program.view.window.ReplaceDevInfoModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.window-replacedevinfo',
    data: {
        name: 'program',
        title:""
    }

});
