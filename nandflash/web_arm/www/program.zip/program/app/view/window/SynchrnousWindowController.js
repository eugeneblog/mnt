Ext.define('program.view.window.SynchrnousWindowController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.window-synchrnouswindow'
    
});
