Ext.define('program.view.tree.DevTreeModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.devtreemodel',
    data: {
        name: 'program',
        linkDataBase: true
    },
    /*fields:[
     {name:"text",type:"string"}
     ]*/
});
