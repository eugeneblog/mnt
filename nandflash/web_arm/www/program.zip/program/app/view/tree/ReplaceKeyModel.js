Ext.define('program.view.tree.ReplaceKeyModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.tree-replacekey',
    data: {
        name: 'program'
    }

});
