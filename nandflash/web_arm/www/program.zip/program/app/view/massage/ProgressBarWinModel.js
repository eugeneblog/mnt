Ext.define('program.view.massage.ProgressBarWinModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.massage-progressbarwin',
    data: {
        name: 'program'
    }

});
