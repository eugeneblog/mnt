Ext.define('program.view.massage.ProgressBarWinController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.massage-progressbarwin'
    
});
