Ext.define('program.view.main.toolbar.TopToolbarModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.main-toolbar-toptoolbar',
    data: {
        name: 'program'
    }

});
