Ext.define('program.view.tab.DrawPanelModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.tab-drawpanel',
    data: {
        name: 'program'
    }

});
