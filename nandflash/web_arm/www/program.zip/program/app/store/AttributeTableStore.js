/**
 * Created by liuzhencai on 2016/12/30.
 */

Ext.define("program.store.AttributeTableStore",{
    extend:"Ext.data.TreeStore",
    alias:"attributetablestore"
})

