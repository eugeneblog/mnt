<?php
    header("Content-type:text/xml;charset=utf-8"); 
    $file_name = $_GET['file_name'];
    $filePath = 'devxml/'.$file_name;

    error_reporting(E_ALL^E_NOTICE^E_WARNING);
    //使用dom查找
    $dom = new DOMDocument("1.0","UTF-8");
    $dom -> load($filePath);

    $root_key = $dom -> getElementsByTagName('key');
    $new_str = '';
    for($i=0;$i<$root_key->length;$i++){
        //遍历节点
        $all_key = $root_key->item($i);
        $key_attrbute = $all_key->getAttribute('number');
        $select_model = substr($key_attrbute,5,1);   //取得十位
        if($select_model == 0 && $select_model == 1){      //判断是否有模块
            return;
        }
        else if($select_model == 2){
            $model_2 = 2;
            continue;
        }
        else if($select_model == 3){
            $model_3 = 3;
            continue;
        }
        else if($select_model == 4){
            $model_4 = 4;
            continue;
        }
        else if($select_model == 5){
            $model_5 = 5;
            continue;
        }
        else if($select_model == 6){
            $model_6 = 6;
            continue;
        }
        else if($select_model == 7){
            $model_7 = 7;
            continue;
        }
    }
    echo $model_2;
    echo $model_3;
    echo $model_4;
    echo $model_5;
    echo $model_6;
    echo $model_7;
    // echo $file_name;
?>