Ext.define('Ext.theme.triton.resizer.Splitter', {
    override: 'Ext.resizer.Splitter',
    
    size: 10
});
