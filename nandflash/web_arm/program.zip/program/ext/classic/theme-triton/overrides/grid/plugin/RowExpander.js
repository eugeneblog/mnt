Ext.define('Ext.theme.triton.grid.plugin.RowExpander', {
    override: 'Ext.grid.plugin.RowExpander',
    
    headerWidth: 32
});