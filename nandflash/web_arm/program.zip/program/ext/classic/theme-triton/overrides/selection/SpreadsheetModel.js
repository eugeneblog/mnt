Ext.define('Ext.theme.triton.grid.selection.SpreadsheetModel', {
    override: 'Ext.grid.selection.SpreadsheetModel',
    
    checkboxHeaderWidth: 32
});