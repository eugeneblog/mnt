Ext.define('Ext.theme.triton.picker.Month', {
    override: 'Ext.picker.Month',
    
    footerButtonUI: 'default-toolbar',
    calculateMonthMargin: Ext.emptyFn
});