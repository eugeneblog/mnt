# theme-crisp-touch/sass/var

This folder contains variable declaration files named by their component class.
