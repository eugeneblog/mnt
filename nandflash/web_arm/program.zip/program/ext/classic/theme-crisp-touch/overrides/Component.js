Ext.define('Ext.theme.crisptouch.Component', {
    override: 'Ext.Component'
}, function() {
    Ext.namespace('Ext.theme.is').CrispTouch = true;
    Ext.theme.name = 'CrispTouch';
});