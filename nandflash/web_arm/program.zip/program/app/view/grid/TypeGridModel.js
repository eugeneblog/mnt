Ext.define('program.view.grid.TypeGridModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.grid-typegrid'
    //fields: ['name', 'value'],

   /* data: {
        name: 'program'
    }*/

});

