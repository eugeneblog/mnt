Ext.define('program.view.grid.LogicGridPanelModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.grid-logicgridpanel',
    data: {
        name: 'program'
    }

});
