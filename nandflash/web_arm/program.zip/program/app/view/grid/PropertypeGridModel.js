Ext.define('program.view.grid.PropertypeGridModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.grid-propertypegrid',
    data: {
        name: 'program'
    }

});
