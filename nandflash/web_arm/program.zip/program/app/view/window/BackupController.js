Ext.define('program.view.window.BackupController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.window-backup'
    
});
