Ext.define('program.view.window.SynchrnousWindowModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.window-synchrnouswindow',
    data: {
        name: 'program'
    }

});
