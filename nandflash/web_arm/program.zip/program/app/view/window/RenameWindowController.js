Ext.define('program.view.window.RenameWindowController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.window-renamewindow',
    types: ['AI', 'AO', 'AV', 'BI', 'BO', 'BV', 'SCHEDULE'],

    boxready: function () {
        var infoExFile = null;
        var me = this.view;             //当前的视图对象  
        var filePath = me.text;
        console.log(me);
        console.log(filePath);
        var types = ['AI', 'AO', 'AV', 'BI', 'BO', 'BV', 'SCHEDULE'];

        var items = [];   //定义一个数组，用循环创建子组件
        for (var i = 0; i < types.length; i++) {   //遍历types,根据types的长度创建相对应的视图
            var fieldcontainer = {
                xtype: "fieldcontainer",
                layout: "hbox",
                defaults: {
                    margin: "0 35"
                },
                typeAdd: function () {

                },
                items: [
                    {
                        fieldStyle: {
                            textAlign: "center"
                        },
                        xtype: "textfield",
                        fieldLabel: types[i],
                        name: types[i],
                        width: 180,
                        itemId: "typeNumber",
                        flex: 5
                    }, {
                        xtype: "button",
                        devType: i,
                        text: "+",
                        flex: 1,
                        handler: addType.bind(me)
                    }, {
                        xtype: "button",
                        text: "-",
                        devType: i,
                        flex: 1,
                        handler: deleteType
                    }
                ]
            }

            items.push(fieldcontainer);
        }
        console.log(items);
        console.log("====================================================================");
        items.push(
            {
                xtype: "fieldcontainer",
                layout: "hbox",
                defaults: {
                    margin: "0 10",
                },
                items: [
                    {
                        fieldStyle: {
                            textAlign: "center"
                        },
                        margin: "0 10 0 35",
                        xtype: "textfield",
                        fieldLabel: "device instance",
                        editable: false,
                        flex: 2,
                        value: me.devName,
                        itemId: "deviceInstance",
                        columnWidth: 10
                    }, {
                        xtype: "button",
                        text: "replace",
                        flex: 1,
                        handler: function (button) {
                            var container = button.up();
                            var oldDevice = container.getComponent("deviceInstance");
                            var newDevice = container.getComponent("replaceDevice");
                            oldDevice.setValue(newDevice.getValue())
                            me.devName = newDevice.getValue();
                            me.deviceName = oldDevice.getValue();
                            me.iterationItems(function (item, i) {
                            })
                            delayToast("Massage", "Replace success");
                        }
                    }, {
                        fieldStyle: {
                            textAlign: "center"
                        },
                        validator: function (val) {
                            if (isNaN(val)) {
                                return "please input number .";
                            }
                            if (val.length != 4 || val < 0 || val > 9999) {
                                return "wrong format ."
                            }
                            return true
                        },
                        itemId: "replaceDevice",
                        xtype: "textfield",
                        flex: 1
                        //marigin:"0 35 0 0"
                    }
                ]
            }
        );
        items.push(
          {
                xtype: "fieldcontainer",
                layout: "hbox",
                id:'modelType',
                defaults: {
                    margin: "0 10",
                },
                 items: [
                    {
                        fieldStyle: {
                            textAlign: "center"
                        },
                        
                        xtype: "textfield",
                        fieldLabel: "Model",
                        editable: false,
                        flex: 6,
                        margin:"0 0 0 34px",
                        value: 2342,
                        itemId: "Model"
                    },
                    
                    
                    {
                        fieldStyle: {
                            textAlign: "center"
                        },
                        xtype: "textfield",
                        value:2,
                        disabled:true,
                        isAdd:false,
                        editable: false,
                        flex: 1
                    },
                    {
                        fieldStyle: {
                            textAlign: "center"
                        },
                        xtype: "textfield",
                        value:3,
                        isAdd:false,
                        disabled:true,
                        editable: false,
                        flex: 1
                    },
                    {
                        fieldStyle: {
                            textAlign: "center"
                        },
                        xtype: "textfield",
                        value:4,
                        disabled:true,
                        isAdd:false,
                        editable: false,
                        flex: 1
                    },
                    {
                        fieldStyle: {
                            textAlign: "center"
                        },
                        xtype: "textfield",
                        value:5,
                        disabled:true,
                        isAdd:false,
                        editable: false,
                        flex: 1
                    },
                    {
                        fieldStyle: {
                            textAlign: "center"
                        },
                        xtype: "textfield",
                        value:6,
                        disabled:true,
                        isAdd:false,
                        editable: false,
                        flex: 1
                    },
                    {
                        fieldStyle: {
                            textAlign: "center"
                        },
                        xtype: "textfield",
                        value:7,
                        disabled:true,
                        isAdd:false,
                        editable: false,
                        flex: 1
                    }
                    ]
            }
            );
            items.push(
                {
                      xtype: "fieldcontainer",
                      layout: "hbox",
                      defaults: {
                          margin: "0 10",
                      },
                       items: [
                        {
                            margin:"0 0 0 34px",
                            xtype: "combobox",
                            flex: 5,
                            // allowBlank: false,
                            fieldLabel: 'select',
                            store: ['EX-0804','EX-4240'],
                            editable: false,
                            // autoSelect: true,
                            itemId: "select",
                            value:'EX-0804',
                        },
                        {
                            fieldStyle: {
                                textAlign: "center"
                            },
                            xtype: "combobox",
                            value:2,
                            itemId:'selectNum',
                            editable: false,
                            store: [2,3,4,5,6,7],
                            flex: 1
                        },{
                            xtype: "button",
                            devType: i,
                            text: "+",
                            flex: 1,
                            handler: addModel,
                            // function(button,item){
                                // var fileName = button.up('form').down('#select').getValue(); //获取select的value
                                // var xmlType = button.up('form').down('#selectNum').getValue(); //获取selectNum 的vlaue
                                // Ext.Ajax.request({
                                //     async:false,
                                //     url:"resources/model/"+fileName+".xml",
                                //     success:function(response){
                                //         var xml = response.responseXML;  // 获取xml所有dom节点
                                //         var domKeys = xml.querySelectorAll('key');  //获取xml所有key节点对象，返回值nodelist类数组对象
                                //         var keys = [];   //将类数组转化为数组
                                //         var newKeys = '';
                                //         for(var i = 0,len = domKeys.length;i<len;i++){
                                //             keys[i] = domKeys[i];
                                //         }
                                //         console.log(keys);
                                //         for(var i=0;i<keys.length;i++){
                                //             var getNumber = keys[i].getAttribute('number');  //获取所有key的属性number
                                //             var newAttrBute = getNumber.split('');
                                //             newAttrBute[5] = xmlType;
                                //             var attrButeText = newAttrBute.join('');   //修改key的number属性
                                //             keys[i].setAttribute('number',attrButeText);
                                //             newKeys += keys[i].outerHTML+'\n';       //xml字符串
                                //         }
                                //         console.log(newKeys);
                                //         console.log(typeof newKeys);
                                //         console.log(keys);
                                //         sendRequest(newKeys);
                                //     }
                                // })
                            //     Ext.Ajax.request({
                            //         async:false,
                            //         url:'resources/xmlInsert.php',
                            //         success:function(response,options){
                            //             var text = response.responseText;
                            //             console.log(text);
                            //         },
                            //         send:function(){

                            //         }
                            //     })
                            // }
                        }, {
                            xtype: "button",
                            text: "-",
                            devType: i,
                            flex: 1,
                            handler: delModel
                        }
                          ]
                  }
                  );

        var panel = Ext.create("Ext.form.Panel", {
            title: "devices",
            items: items,    //将子组件加入panel
            bodyPadding: 20,
            minHeight: 350
        });

        panel.getForm().setValues(me.getFormValues());  //获取panel的form对象，批量设置表单内的字段值
        console.log(panel.getForm())
        me.insert(0, panel);//添加容器到指定位置
        
        panel.expand();//展开panel所有节点
        
        // var ex_08=[];
        // // console.log(ex_08)
        // ex_08.push(
        //     {
        //         xtype: "fieldcontainer",
        //         layout: "hbox",
        //         defaults: {
        //             margin: "0 10",
        //             },
        //         items:[
        //             {
        //                 fieldStyle: {
        //                     textAlign: "center"
        //                 },
                        
        //                 xtype: "textfield",
        //                 fieldLabel: "Model",
        //                 editable: false,
        //                 flex: 6,
        //                 margin:"0 0 0 34px",
        //                 value: 2342,
        //                 itemId: "Model"
        //             },
                    
                    
        //             {
        //                 fieldStyle: {
        //                     textAlign: "center"
        //                 },
        //                 xtype: "textfield",
        //                 value:2,
        //                 flex: 1
        //             },
        //         ]
        //     }
        // );
        // var panel1= Ext.create("Ext.form.Panel", {
        //     title: "devices1",
        //     items: ex_08,
        //     bodyPadding: 20,
        //     minHeight: 320
        // });
        // panel1.getForm().setValues(me.getFormValues());
        // me.insert(1,panel1);
        // panel1.expand();
    //    ----------------------------------------===========================================================
        function addType(button) {  //传入button对象   ，添加类型

            var lastText = me.sDevName + button.devType;    //当前操作的xml文件名 + 按钮的 devtype

            var netNumbers = []     //device instance select框的值
            for (var i = 0; i <= 9900; i += 100) {
                netNumbers.push(i)
            }
            var modelAddress = []; //instance select 框的值
            for (var i = 0; i <= 99; i++) {
                modelAddress.push(i);
            }
            var pointType = [];    //point select 的值
            for (var i = 0; i < types.length; i++){
                pointType.push({
                    name: types[i],
                    value: i
                })
            }
            // console.log(types);

            //console.log(button.devType)
            //console.log(button.up().getComponent("typeNumber").value)
            //console.log(me)

            var refDev;
            if (me.devName) {
                refDev = me.devName;
            } else {
                refDev = me.sDevName;
            }
            //console.log(refDev);
            var keyField = Ext.create("Ext.form.field.Text", {
                margin: 10,
                fieldLabel: "Key",
                value: (refDev || "9901") + button.devType + "01"
            })

            var win = Ext.create('Ext.window.Window', {    //增加AI..BI 的弹窗视图
                title: 'Add •••',
                frame: true,
                width: 325,
                bodyPadding: 10,
                autoShow: true,
                defaultType: 'textfield',
                defaults: {
                    anchor: '100%'
                },
                items: [
                    {
                        margin: 10,
                        xtype: "combobox",
                        allowBlank: false,
                        fieldLabel: 'device instance',
                        store: netNumbers,
                        editable: false,
                        queryMode: 'local',
                        autoSelect: false,
                        value: refDev || "9901",
                        listeners: {
                            change: function (field, newValue, oldValue) {

                                var instance = win.getComponent("instance");
                                var instanceValue = (newValue + "").substr(2, 2)
                                instance.setValue(instanceValue)

                                var value = Ext.String.leftPad(newValue, 4, "0");
                                var values = keyField.getValue().split("");
                                values[0] = value[0];
                                values[1] = value[1];
                                keyField.setValue(values.join(''))

                                //Ext.String.insert //补0
                            }
                        }
                    },
                    {
                        margin: 10,
                        xtype: "combobox",
                        allowBlank: false,
                        fieldLabel: 'instance',
                        store: modelAddress,
                        editable: false,
                        itemId: "instance",
                        queryMode: 'local',
                        autoSelect: false,
                        value: refDev.substr(2, 2),
                        listeners: {
                            change: function (field, newValue, oldValue) {
                                var value = Ext.String.leftPad(newValue, 2, "0");
                                var values = keyField.getValue().split("");
                                values[2] = value[0]
                                values[3] = value[1]
                                keyField.setValue(values.join(''))
                            }
                        }

                    },
                    {
                        margin: 10,
                        xtype: "combobox",
                        allowBlank: false,
                        fieldLabel: 'Point Type',
                        store: Ext.create("Ext.data.Store", {
                            fields: ['name', "value"],
                            data: pointType
                        }),
                        valueField: "value",
                        displayField: "name",
                        editable: false,
                        queryMode: 'local',
                        autoSelect: false,
                        listeners: {
                            afterrender: function (combo) {
                                combo.setValue(combo.store.getAt(button.devType));
                            },
                            change: function (field, newValue, oldValue) {
                                var value = newValue;
                                var values = keyField.getValue().split("");
                                values[4] = value
                                keyField.setValue(values.join(''))

                                var pn = field.up().getComponent("pointNumber");
                                if (newValue == 2 || newValue == 5) {
                                    pn.setMaxValue(15)
                                    if (pn.value > 15) {
                                        pn.setValue(15)
                                    }
                                } else {
                                    pn.setMaxValue(24)
                                }

                            }
                        }
                    },
                    {
                        margin: 10,
                        xtype: "numberfield",
                        allowBlank: false,
                        fieldLabel: 'Point Number',
                        //store: modelAddress,
                        maxValue: 24,
                        minValue: 0,
                        editable: false,
                        itemId: "pointNumber",
                        queryMode: 'local',
                        autoSelect: false,
                        value: "01",
                        listeners: {
                            change: function (field, newValue, oldValue) {
                                var value = Ext.String.leftPad(newValue, 2, "0");
                                var values = keyField.getValue().split("");
                                values[5] = value[0]
                                values[6] = value[1]
                                keyField.setValue(values.join(''))
                            }
                        }

                    },
                    keyField
                ],
                buttons: [
                    {
                        text: 'Ok', handler: function () {    //ok点击事件发生后调用一个处理程序

                        var text = keyField.getValue();    //获取文件名

                        /*if (text == null) {
                         Ext.Msg.alert('Info', 'Plase select file name.');
                         return;
                         }*/

                        //win.close();

                        if (isNaN(text) || text.length != 7) {     //判断text是不是非数值，和text的长度是否不等于7位数，有一个条件满足则提示用户不符合要求
                            Ext.Msg.alert("Key Exception", "The key ,Does not meet the requirements")
                            return
                        }

                        if (me.query('[key=' + text + ']').length) {  
                            Ext.Msg.alert("Key Exception", "has been " + text)
                            return
                        }

                        var typeNumber = text.substr(4, 1);
                        if (me.getFormValues().SCHEDULE >= 5) {
                            Ext.Msg.alert("Massage","SCHDULE max is 5");
                            return ;
                        }
                        var objname = types[typeNumber] + text.substr(5, 2);
                        Ext.MessageBox.prompt("Input", "New Name", function (ms, v) {
                            if (ms != 'ok') {
                                return;
                            }

                            me.insrtDevForm(text, v);
                            panel.getForm().setValues(me.getFormValues());
                            Ext.Msg.alert("Massage", "Ok.")
                        }, this, false, objname);

                        //panel.getForm().setValues(me.getFormValues());

                    }
                    },
                    {
                        text: 'Close', handler: function () {
                        win.close();
                    }
                    }
                ]
            })

            /*Ext.MessageBox.prompt('Add •••', 'Please enter your key:', function (ms, v, scope) {
             if (ms == 'ok') {
             if (v.length == 7 & v.substr(0, 5) == lastText & !isNaN(v)) {
             window.insrtDevForm(v);
             } else {
             Ext.Msg.alert('Exception', "Please enter 7 digits after two .")
             }

             }
             }, this, false, lastText);
             */


        }
        //---------------------------------------删除模块------------------------------------------------
        function deleteType(button) {  //删除类型


            var win = Ext.create('Ext.window.Window', {
                title: 'Delete •••',
                frame: true,
                width: 325,
                bodyPadding: 10,
                autoShow: true,
                defaultType: 'textfield',
                defaults: {
                    anchor: '100%'
                },
                items: [
                    {
                        margin: 10,
                        xtype: "combobox",
                        allowBlank: false,
                        fieldLabel: 'select file name',
                        store: Ext.create("Ext.data.Store", {
                            fields: ['key', "title"],
                            data: me.getFormValues()['type' + button.devType]
                        }),
                        editable: false,
                        queryMode: 'local',
                        displayField: 'title',
                        valueField: 'key',
                        autoSelect: false
                    }
                ],
                buttons: [
                    {
                        text: 'Ok', handler: function () {
                        var text = win.down("combobox").getValue();

                        if (text == null) {
                            Ext.Msg.alert('Info', 'Plase select file name.');
                            return;
                        }else{
                            
                            // Ext.Ajax.request({
                            //     url:"resources/inspect.php",
                            //     method:"GET",
                            //     params: { file_name: text,parent_file:filePath},
                            //     success:function(response,opts){
                            //         var result = response.responseText;
                            //         console.log(result);
                            //     }
                            // })
                            // console.log('检查xml是否有model');
                            me.deleteDevForm(text);

                            panel.getForm().setValues(me.getFormValues());
                            win.close();
                        }

                    }
                    },
                    {
                        text: 'Close', handler: function () {
                        win.close();
                    }
                    }
                ]
            })

        };
        // ====================================================================================
        function addModel(button){
            var fileName = button.up('form').down('#select').getValue(); //获取select的value
            
            var xmlType =  button.up('form').down('#selectNum').getValue(); //获取selectNum 的vlaue
            var allInput = Ext.ComponentQuery.query('#modelType')[0].items.items;

            //遍历所有items，加上禁用
            for(var i = 1,len = allInput.length;i < len;i++){
                // allInput[i].setDisabled(true);
                if(parseInt(allInput[i].value) === xmlType){
                    if(allInput[i].disabled == true){
                        allInput[i].setDisabled(false);
                        console.log('加载异步请求');
                        Ext.Ajax.request({
                            url:"resources/xmlInsert.php",
                            method:"GET",
                            params: { file_name: fileName+'.xml', select_num: xmlType ,parent_file:filePath},
                            success:function(response,opts){
                                var xml = response.responseText;
                                console.log(xml);
                                console.log("成功，异步请求加载完成")
                                console.log(filePath);
                                Ext.MessageBox.alert('成功','已经从服务器端获取结果');
                            },
                            failure:function(response,opts){
                                Ext.MessageBox.alert("失败",'请求超时或网络故障，错误编号: ' + response.status);
                            }
                        });
                    }else{
                        Ext.MessageBox.alert("警告",'已经添加该模块');
                        return;
                    }
                    
                }
            }
            console.log(allInput);
        }
        //=========================================================================================
        function delModel(button){
            var fileName = button.up('form').down('#select').getValue(); //获取select的value
            var xmlType =  button.up('form').down('#selectNum').getValue(); //获取selectNum 的vlaue
            var allInput = Ext.ComponentQuery.query('#modelType')[0].items.items;
            for(var i = 1,len = allInput.length;i < len;i++){
                // allInput[i].setDisabled(true);
                
                if(parseInt(allInput[i].value) === xmlType){
                    // allInput[i].disabled = true;
                    Ext.Ajax.request({
                        url:"resources/delmodel.php",
                        method:"GET",
                        params: { file_name: fileName+'.xml', select_num: xmlType ,parent_file:filePath},
                        success:function(response,opts){
                            var result = response.responseText;
                            Ext.MessageBox.alert('成功','已将模块删除');
                        }
                    });
                    // console.log(allInput[i].disabled);  
                    allInput[i].disabled == false?allInput[i].setDisabled(true): console.log('已经删除');
                }
            }
            console.log(allInput);
        }
    }
});
