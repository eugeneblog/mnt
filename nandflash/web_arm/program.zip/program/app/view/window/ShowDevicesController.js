Ext.define('program.view.window.ShowDevicesController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.window-showdevices'
    
});
