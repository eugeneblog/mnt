Ext.define('program.view.window.ShowDevicesModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.window-showdevices',
    data: {
        name: 'program'
    }

});
