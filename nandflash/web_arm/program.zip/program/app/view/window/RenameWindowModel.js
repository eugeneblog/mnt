Ext.define('program.view.window.RenameWindowModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.window-renamewindow',
    data: {
        name: 'program'
    }

});
