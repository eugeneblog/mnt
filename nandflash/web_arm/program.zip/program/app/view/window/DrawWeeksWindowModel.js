Ext.define('program.view.window.DrawWeeksWindowModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.window-drawweekswindow',
    data: {
        name: 'program',
        modify:[{0:false}]
    }

});
